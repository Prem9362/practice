import streamlit as st
import requests

st.title("Student Marks Prediction")

age = st.number_input("Enter age", value=None, placeholder="Enter age")
study_hours_per_day = st.number_input("Enter study hours", value=None, placeholder="Enter study hours")
attendance_percentage = st.number_input("Enter attendance %", value=None, placeholder="Enter attendance %")
previous_exam_score = st.number_input("Enter previous exam score", value=None, placeholder="Enter previous exam score")
assignments_completed_percentage = st.number_input("Enter assignment percentage", value=None, placeholder="Enter assignment percentage")
sleep_hours = st.number_input("Enter sleep hours", value=None, placeholder="Enter sleep hours")
social_media_hours = st.number_input("Enter social media hours", value=None, placeholder="Enter social media hours")
practice_tests_completed = st.number_input("Enter practice tests completed", value=None, placeholder="Enter practice tests completed")

if st.button("SUBMIT"):

    obj1 = {
        "age": age,
        "study_hours_per_day": study_hours_per_day,
        "attendance_percentage": attendance_percentage,
        "previous_exam_score": previous_exam_score,
        "assignments_completed_percentage": assignments_completed_percentage,
        "sleep_hours": sleep_hours,
        "social_media_hours": social_media_hours,
        "practice_tests_completed": practice_tests_completed
    }

    url = "http://127.0.0.1:8000/predict"

    try:
        response = requests.post(url=url, json=obj1)
        response.raise_for_status()

        output = response.json()

        st.success(
            f"Predicted Final Exam Score: "
            f"{output['Predicted_Final_Exam_Score']}"
        )

    except requests.exceptions.RequestException as e:
        st.error(f"API request failed: {e}")