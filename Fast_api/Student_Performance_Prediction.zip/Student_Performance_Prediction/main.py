from fastapi import FastAPI
from pydantic import BaseModel
import pickle


app=FastAPI()

class model(BaseModel):
    age:int
    study_hours_per_day:float
    attendance_percentage:float
    previous_exam_score:float
    assignments_completed_percentage:float
    sleep_hours:float
    social_media_hours:float
    practice_tests_completed:int

final_model=pickle.load(open('student_pred.pkl','rb'))

@app.get('/')
def hello():
    return 'Hello'

@app.post('/predict')
def predict(obj:model):
    q=[[obj.age,
        obj.study_hours_per_day,
        obj.attendance_percentage,
        obj.previous_exam_score,
        obj.assignments_completed_percentage,
        obj.sleep_hours,
        obj.social_media_hours,
        obj.practice_tests_completed]]
    yp = final_model.predict(q)
    prediction = round(float(yp[0]), 2)
    return {"Predicted_Final_Exam_Score": prediction}